<?php
#Salir si alguno de los datos no está presente
#if(!isset($_POST["medicamento"]) || !isset($_POST["fecha_inicio_dia"]) || !isset($_POST["fecha_inicio_mes"]) || !isset($_POST["fecha_inicio_año"]) || !isset($_POST["tomas"])) exit();

#Si todo va bien, se ejecuta esta parte del código...

include_once "base_de_datos.php";
$nombre = $_POST["medicamento"];
$dia_inicio = $_POST["fecha_inicio_dia"];
$mes_inicio = $_POST["fecha_inicio_mes"];
$año_inicio = $_POST["fecha_inicio_año"];
$fecha_inicio = $dia_inicio . '-' . $mes_inicio . '-' . $año_inicio;

function fecha_finalizacion(){
    if (isset($_POST["fecha_fin_dia"]) and isset($_POST["fecha_fin_mes"]) and isset($_POST["fecha_fin_año"])){
        $dia_fin = $_POST["fecha_fin_dia"];
        $mes_fin = $_POST["fecha_fin_mes"];
        $año_fin = $_POST["fecha_fin_año"];
        $fecha_fin = $dia_fin . '-' . $mes_fin . '-' . $año_fin;
    } else {
        $fecha_fin = NULL;
    }
    return $fecha_fin;
}

$fecha_final = fecha_finalizacion();

function fecha_vencimiento(){
    if (isset($_POST["fecha_ven_dia"]) and isset($_POST["fecha_ven_mes"]) and isset($_POST["fecha_ven_año"])){
        $dia_ven = $_POST["fecha_ven_dia"];
        $mes_ven = $_POST["fecha_ven_mes"];
        $año_ven = $_POST["fecha_ven_año"];
        $fecha_ven = $dia_ven . '-' . $mes_ven . '-' . $año_ven;
    } else {
        $fecha_ven = NULL;
    }
    return $fecha_ven;
}

$fecha_vence = fecha_vencimiento();

function tomar(){
    if (isset($_POST["8"])){
        $tomando = $_POST["8"];
    } elseif (isset($_POST["10"])){
        $tomando = $_POST["10"];
    } else {
        if (isset($_POST["12"])) {
            $tomando = $_POST["12"];
        } else {
            if (isset($_POST["tomas"])){
            $tomando = $_POST["tomas"];
            } else {
                $tomando = 24;
            }
        }
        
    }
    return $tomando;
}

$tomas = tomar();

function unidad(){
    if (isset($_POST["dosis"])) {
        if (isset($_POST["mg"])){
            $unidad = $_POST["mg"];
        } elseif (isset($_POST["g"])){
            $unidad = $_POST["g"];
        } else {
            $unidad = " ";
        }
    } else {
        $unidad = " ";
    }
    return $unidad;
}

if (isset($_POST["dosis"])) {
    $num_dosis = $_POST["dosis"];
    $uni = unidad();
    $dosis = $num_dosis . $uni;
} else {
    $dosis = NULL;
}


/*
	Al incluir el archivo "base_de_datos.php", todas sus variables están
	a nuestra disposición. Por lo que podemos acceder a ellas tal como si hubiéramos
	copiado y pegado el código
*/

$base_de_datos = obtenerBaseDeDatos();

$sentencia = $base_de_datos->prepare("INSERT INTO medicamento(nombre, dosis, fecha_inicio, fecha_fin, fecha_vencimiento, tomas) VALUES (?, ?, ?, ?, ?, ?);");

$resultado = $sentencia->execute([$nombre, $dosis, $fecha_inicio, $fecha_final, $fecha_vence, $tomas]); # Pasar en el mismo orden de los ?
#execute regresa un booleano. True en caso de que todo vaya bien, falso en caso contrario.
#Con eso podemos evaluar
if($resultado === TRUE) {
    echo "Insertado correctamente";
} else {
    echo "Algo salió mal. Por favor verifica que la tabla exista";
}


?>