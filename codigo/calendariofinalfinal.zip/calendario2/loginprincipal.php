<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Med Calendar</title> 
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" href="estilos.css">
	

</head>  
<body>
    <form class="formulario" action="login.php" method="post">
    <img src="logo.png" alt="logo" />

    <h1>Iniciar sesión</h1>
     <div class="contenedor">
     
     
         
         <div class="input-contenedor">
         <i class="fas fa-user icon"></i>
         <input name="correo" type="text" placeholder="Usuario">
         
         </div>
         
         <div class="input-contenedor">
        <i class="fas fa-key icon"></i>
         <input name="palabra_secreta" type="password" placeholder="Contraseña">
         
         </div>
         <?php
       if(isset($_GET["fallo"]) && $_GET["fallo"] == 'true')
       {
          echo "<div style='color:red'>Usuario o contraseña invalido </div>";
       }
     ?>
         <input type="submit" value="Ingresar" class="button">
         <p>También puedes <a class="link" href="registro.php">Crear un usuario </a></p>
     </div>
    </form>
</body>
</html>