<?php


include_once "base_de_datos.php";
$base_de_datos = obtenerBaseDeDatos();

$nombre = $_POST["nombre"];

if (isset($_POST["fecha_ven_dia"]) and isset($_POST["fecha_ven_mes"]) and isset($_POST["fecha_ven_año"])){
    $dia_ven = $_POST["fecha_ven_dia"];
    $mes_ven = $_POST["fecha_ven_mes"];
    $año_ven = $_POST["fecha_ven_año"];
    $fecha_ven = $dia_ven . '-' . $mes_ven . '-' . $año_ven;
    $sentencia = $base_de_datos->prepare("UPDATE medicamento SET fecha_vencimiento = ? WHERE nombre = ?;");
    $resultado_ven = $sentencia->execute([$fecha_ven, $nombre]);
    if($resultado_ven === TRUE){
        echo "Cambios guardados";
    } else {
        echo "Algo salió mal. Por favor verifica que la tabla exista, así como el ID del usuario";
    }
}
?>