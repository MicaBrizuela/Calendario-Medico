<?php
# Si no entiendes el código, primero mira a login.php
# Iniciar sesión para usar $_SESSION
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

<title>Calendario</title>
<link rel="stylesheet" type="text/css" href="calendario.css" media="all"/>
<script type="text/javascript" src="calendario.js"></script>
</head>
<body>
<div id="calendario">

 

  <div id="anterior" onclick="mesantes()">  </div>
  <div id="posterior" onclick="mesdespues()">  </div>
  <h2 id="titulos"></h2>
  <table id="diasc">
    <tr id="fila0"><th></th><th></th><th></th><th></th><th></th><th></th><th></th></tr><br>
    <tr id="fila1"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><br>
    <tr id="fila2"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><br>
    <tr id="fila3"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><br>
    <tr id="fila4"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><br>
    <tr id="fila5"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><br>
    <tr id="fila6"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><br>
  </table>

  </div>
  <div id="fechaactual"></div>
  <div id="hoy" onclick="actualizar()"> <p> HOY </p> </div>
      <div id="user">
      <!-- <img id="user" src="user.png" />
      <p id="user-texto"> MI user </p> -->
      <div class="dropdown">
        <button class="dropbtn">
          <img onclick="myFunction()" class="dropbtn" id="user_icon" src="user.png" />
        </button>
		<div id="myDropdown" class="dropdown-content">
          <img  src="userprueba.png" class="user-pic"/>
		  <br><br><br>
		  <?php
# Podemos recuperar datos de la sesión
echo "<p class='user-name'>" . $_SESSION["correo"] . "</p>";
?>
          <!--<p class="user-name"> NOMBRE APELLIDO </p> -->
          <a href="logout.php" style="position: absolute; top:60%;">Cerrar sesión</a>
    </div>

  </div>
  </div>
    <button class="boton" value="Load new document" onclick="ventanaSecundaria1()">
    Agregar medicamento
    <script>
	function ventanaSecundaria1 (){ 
    window.open("agrega_med.html") 
	}
	</script>
	</button>
	
  
  <div style="position: absolute;left: 1%; top:110px">
    <button class="boton" value="Load new document" onclick="ventanaSecundaria2()">
    Editar medicamento
	<script>
	function ventanaSecundaria2 (){ 
    window.open("editar_med.html")
	}
	</script>
    </button>
  </div>
  <div style="position: absolute; left: 1%; top:220px">
    <button class="boton" value="Load new document" onclick="ventanaSecundaria3()">
    Eliminar medicamento
	<script>
	function ventanaSecundaria3 (){ 
    window.open("eliminar_med.html") 
	}
	</script>
    </button>
  </div>
  
  
    <?php
    include_once "base_de_datos.php";
    $base_de_datos = obtenerBaseDeDatos();
    $sentencia = $base_de_datos->query("select nombre, dosis from medicamento");
    $mascotas = $sentencia->fetchAll(PDO::FETCH_OBJ); #no cambiar el nombre, sino no funciona 
    ?> 
    <div id="tablita"> Próximas tomas 
			<table>
				<thead>
					<tr>
						<th>Nombre</th>
						<th>Dosis</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach($mascotas as $mascota){ #no cambiar el nombre, sino no funciona
					?> 
						<tr>
							<td><?php echo $mascota->nombre ?></td>
							<td><?php echo $mascota->dosis ?></td>
							</tr>
					<?php } ?>
				</tbody>
			</table>
  </div>
</body>

</html>
