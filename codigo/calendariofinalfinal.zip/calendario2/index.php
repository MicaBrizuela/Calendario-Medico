<?php
header("Location: registro.php");
?>