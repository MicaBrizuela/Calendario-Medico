<?php
$id = $_POST["nombre"];
include_once "base_de_datos.php";
$base_de_datos = obtenerBaseDeDatos();
$sentencia = $base_de_datos->prepare("DELETE FROM medicamento WHERE nombre = ?;");
$resultado = $sentencia->execute([$id]);

if($resultado === TRUE){
    echo "Eliminado correctamente";
} else {
    echo "Algo salió mal";
}
?>