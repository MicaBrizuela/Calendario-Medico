<?php
session_start();

if (empty($_SESSION["correo"])) {
    # Lo redireccionamos al formulario de inicio de sesión
    header("Location: loginprincipal.php");
    # Y salimos del script
    exit();
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>

<title>Calendario</title> 
<link rel="stylesheet" type="text/css" href="calendario.css" media="all" />
<script type="text/javascript" src="calendario.js"></script>
</head>
<body>

<header>
    
  <div id="top-header">

    <div>
      <img id="logo" src="logo.png" />
    </div>
    
    <div>
      <img id="user" src="user.png" />
      <p id="perfil-texto"> MI PERFIL </p>
    </div>

  </div>
</header>



<div id="calendario">
  <div id="anterior" onclick="mesantes()"></div>
  <div id="posterior" onclick="mesdespues()"></div>
  <h2 id="titulos"></h2>
  <table id="diasc">
    <tr id="fila0"><th></th><th></th><th></th><th></th><th></th><th></th><th></th></tr>
    <tr id="fila1"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <tr id="fila2"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <tr id="fila3"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <tr id="fila4"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <tr id="fila5"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
    <tr id="fila6"><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr>
  </table>
  </div>



  <div>
    <button id="boton"> 
      Agregar medicamento
    </button>
  </div>
  <div id="fechaactual"></div>
  <div id="hoy" onclick="actualizar()"> <p> HOY </p> </div>
  
  

<?php
echo "<br>Su usuario es: <strong>" . $_SESSION["correo"] . "</strong>";
?>
<p></p>
<a href="logout.php">Cerrar sesión</a>
</body>
</html>