<!DOCTYPE html>
<html lang="es">
<head>
	<title>Registro Med Calendar</title>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" >
	<link rel="stylesheet" href="estilos.css">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>  
<body>
 <form action="registrar.php" method="post" class="formulario">

    <img src="logo.png" alt="logo" />
    
    <h1>Crear usuario</h1>
     <div class="contenedor">
     
     <div class="input-contenedor">
         <i class="fas fa-user icon"></i>
         <input required name="correo" type="text" placeholder="Nuevo usuario">
         
         </div>
         
         <div class="input-contenedor">
         <i class="fas fa-key icon"></i>
         <input required name="palabra_secreta" type="password" placeholder="Nueva contraseña">
         
         </div>
         
         <div class="input-contenedor">
        <i class="fas fa-key icon"></i>
         <input required name="palabra_secreta_confirmar" type="password" placeholder="Confirmar contraseña">
         </div>
          <?php
       if(isset($_GET["fallo"]) && $_GET["fallo"] == 'true')
       {
          echo "<div style='color:red'>Las contraseñas no coinciden, intente nuevamente </div>";
       }
         if(isset($_GET["usrexiste"]) && $_GET["usrexiste"] == 'true')
       {
          echo "<div style='color:red'> Usuario ya creado </div>";
       }
         if(isset($_GET["regbien"]) && $_GET["regbien"] == 'true')
       {
          echo "<script type='text/javascript' style='color:green'>alert('Usuario registrado correctamente');</script>";
          //echo "<div style='color:red'> Usuario registrado correctamente </div>";
       }
         if(isset($_GET["regmal"]) && $_GET["regmal"] == 'true')
       {
           echo "<script type='text/javascript' style='color:red'>alert('Error al registrarte. Intenta más tarde');</script>";
          //echo "<div style='color:red'> Error al registrarte. Intenta más tarde </div>";
       }
     ?>
         <input type="submit" value="Añadir" class="button">
         <p>¿Ya tienes una cuenta?<a class="link" href="loginprincipal.php"> Iniciar Sesión</a></p>
     </div>
    </form>
</body>
</html>