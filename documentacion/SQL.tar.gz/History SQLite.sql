--- 14-06-2022 18:46:53
--- SQLite
/***** ERROR ******
near "demo": syntax error
 ----- 
DELETE demo;
*****/

--- 14-06-2022 18:47:54
--- SQLite
/***** ERROR ******
near "TABLE": syntax error
 ----- 
DELETE TABLE demo;
*****/

--- 14-06-2022 18:48:01
--- SQLite
DELETE FROM demo;

--- 14-06-2022 18:56:12
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 18:56:35
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 18:56:44
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO:;
*****/

--- 14-06-2022 18:59:19
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 18:59:32
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO:;
*****/

--- 14-06-2022 19:01:12
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE testDB;
*****/

--- 14-06-2022 19:08:36
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE "Usuario";
*****/

--- 14-06-2022 19:10:48
--- SQLite
CREATE TABLE Persons (
    PersonID int,
    LastName varchar(255),
    FirstName varchar(255),
    Address varchar(255),
    City varchar(255)
);

--- 14-06-2022 19:11:11
--- SQLite
/***** ERROR ******
near "Persons": syntax error
 ----- 
DELETE Persons;
*****/

--- 14-06-2022 19:11:16
--- SQLite
/***** ERROR ******
near "Persons": syntax error
 ----- 
DELETE Persons;
*****/

--- 14-06-2022 19:11:24
--- SQLite
DELETE FROM Persons;

--- 14-06-2022 19:11:33
--- SQLite
DELETE FROM Persons;

--- 14-06-2022 19:11:38
--- SQLite
DROP TABLE Persons;

--- 14-06-2022 19:12:07
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 19:12:19
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 19:13:28
--- SQLite
/***** ERROR ******
near "DATA": syntax error
 ----- 
CREATE DATA USUARIO;
*****/

--- 14-06-2022 19:14:18
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 19:15:35
--- SQLite
DROP TABLE demo;

--- 14-06-2022 19:15:40
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 19:15:49
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE "USUARIO";
*****/

--- 14-06-2022 19:17:18
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE FROM USUARIO;
*****/

--- 14-06-2022 19:17:23
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE FROM USUARIO;
*****/

--- 14-06-2022 19:17:44
--- SQLite
/***** ERROR ******
near "FROM": syntax error
 ----- 
CREATE FROM DATABASE USUARIO;
*****/

--- 14-06-2022 19:17:56
--- SQLite
/***** ERROR ******
near "FROM": syntax error
 ----- 
CREATE TABLE FROM USUARIO;
*****/

--- 14-06-2022 19:18:02
--- SQLite
/***** ERROR ******
near ";": syntax error
 ----- 
CREATE TABLE USUARIO;
*****/

--- 14-06-2022 19:21:25
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
SHOW DATABASE USUARIO;
CREATE DATABASE MEDICAMENTO;
SHOW DATABASE MEDICAMENTO;
*****/

--- 14-06-2022 19:22:18
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
SHOW DATABASE USUARIO;
*****/

--- 14-06-2022 19:23:41
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE USUARIO;
*****/

--- 14-06-2022 19:24:19
--- SQLite
/***** ERROR ******
near "DATABASE": syntax error
 ----- 
CREATE DATABASE usuario;
*****/

--- 14-06-2022 19:42:13
--- SQLite
CREATE TABLE CLIENTES (ID_USUARIO INT (100) NOT NULL,
NOMBRE VARCHAR (100) NOT NULL,
DESCRIPCION VARCHAR (100) NULL,
CONTRASEÑA VARCHAR (100) NOT NULL,               
MEDICAMENTO VARCHAR (100)NOT NULL,
FOTO_PERFIL BLOB NULL,
PRIMARY KEY (ID_USUARIO));

--- 14-06-2022 19:44:04
--- SQLite
DROP TABLE CLIENTES;

--- 14-06-2022 19:52:26
--- SQLite
/***** ERROR ******
near "CREATE": syntax error
 ----- 
CREATE TABLE CLIENTES (ID_USUARIO INT (100) NOT NULL,
NOMBRE VARCHAR (100) NOT NULL,
DESCRIPCION VARCHAR (100) NULL,
CONTRASEÑA VARCHAR (100) NOT NULL,               
MEDICAMENTOS VARCHAR (100)NOT NULL,
FOTO_PERFIL BLOB NULL,
PRIMARY KEY (ID_USUARIO))

CREATE TABLE MEDICAMENTO (ID_MEDICAMENTO INT (100) NOT NULL,
USUARIO_CORRESPONDIENTE INT (100) NOT NULL,
NOMBRE VARCHAR (100) NOT NULL,
FECHA_INICIO DATE (100) NOT NULL,               
FECHA_FINAL DATE (100) NOT NULL,
HORARIO TIME (100) NOT NULL,
PRIMARY KEY (ID_MEDICAMENTO)),
FOREIGN KEY (USUARIO_CORRESPONDIENTE);
*****/

--- 14-06-2022 19:52:39
--- SQLite
/***** ERROR ******
near "CREATE": syntax error
 ----- 
CREATE TABLE CLIENTES (ID_USUARIO INT (100) NOT NULL,
NOMBRE VARCHAR (100) NOT NULL,
DESCRIPCION VARCHAR (100) NULL,
CONTRASEÑA VARCHAR (100) NOT NULL,               
MEDICAMENTOS VARCHAR (100)NOT NULL,
FOTO_PERFIL BLOB NULL,
PRIMARY KEY (ID_USUARIO))

CREATE TABLE MEDICAMENTO (ID_MEDICAMENTO INT (100) NOT NULL,
USUARIO_CORRESPONDIENTE INT (100) NOT NULL,
NOMBRE VARCHAR (100) NOT NULL,
FECHA_INICIO DATE (100) NOT NULL,               
FECHA_FINAL DATE (100) NOT NULL,
HORARIO TIME (100) NOT NULL,
PRIMARY KEY (ID_MEDICAMENTO),
FOREIGN KEY (USUARIO_CORRESPONDIENTE));
*****/

--- 14-06-2022 19:52:47
--- SQLite
CREATE TABLE CLIENTES (ID_USUARIO INT (100) NOT NULL,
NOMBRE VARCHAR (100) NOT NULL,
DESCRIPCION VARCHAR (100) NULL,
CONTRASEÑA VARCHAR (100) NOT NULL,               
MEDICAMENTOS VARCHAR (100)NOT NULL,
FOTO_PERFIL BLOB NULL,
PRIMARY KEY (ID_USUARIO));

